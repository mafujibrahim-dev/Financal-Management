"""Builds a single-file demo (October 2026 data preloaded, Google sync disabled) for previewing the app."""
import json, pathlib, sys
app = pathlib.Path(sys.argv[1]); out = pathlib.Path(sys.argv[2])
html = (app / 'index.html').read_text()
css = (app / 'styles.css').read_text()
lib = (app / 'xlsx-lite.js').read_text()
js = (app / 'app.js').read_text()
seed = json.loads((app / 'seed.json').read_text())

js = js.replace("if ('serviceWorker' in navigator && location.protocol !== 'file:')", "if (false)")
js += """
// Demo: preload the October 2026 workbook on first open (opening balances + Prod Log already in Transection).
if (!rows('Ledger').length) {
  const S = window.__SEED__;
  ['Ledger', 'Dues', 'Purchases'].forEach(t => (S[t] || []).forEach(r => {
    db[t][r.id] = Object.assign({ deleted: false }, JSON.parse(JSON.stringify(r)), t === 'Purchases' ? { inLedger: true } : {});
  }));
  S.opening.accounts.forEach(a => { const ex = rows('Accounts').find(x => x.name === a.name); if (ex) ex.opening = a.opening; });
  db.Profile.profile = { id: 'profile', startDate: S.opening.startDate, updatedAt: new Date().toISOString() };
  TABLES.forEach(t => { db.dirty[t] = {}; });
  changed(); persist(); render();
}
"""
banner = ('<div style="background:#fef3c7;color:#92400e;font-size:12px;text-align:center;padding:6px">'
          'Preview with your October 2026 data. Google Sheet sync works in the hosted version.</div>')
for tag in ('<link rel="manifest" href="manifest.webmanifest">', '<link rel="icon" href="icons/icon.svg" type="image/svg+xml">',
            '<link rel="apple-touch-icon" href="icons/icon-192.png">'):
    html = html.replace(tag, '')
html = html.replace('<link rel="stylesheet" href="styles.css">', f'<style>{css}</style>')
html = html.replace('<main id="view"', banner + '\n  <main id="view"')
html = html.replace('<script src="xlsx-lite.js"></script>', f'<script>{lib}</script>')
html = html.replace('<script src="app.js"></script>',
                    '<script>window.__SEED__ = ' + json.dumps(seed, ensure_ascii=False) + ';</script>\n  <script>' + js + '</script>')
out.write_text(html)
print(out, len(html))
