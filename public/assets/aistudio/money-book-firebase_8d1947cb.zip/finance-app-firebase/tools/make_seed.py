"""Convert the October 2026 workbook into seed.json for the app.
Usage: python3 -I make_seed.py <workbook.xlsx> <out.json>"""
import sys, json, re, datetime, openpyxl

src, out = sys.argv[1], sys.argv[2]
wb = openpyxl.load_workbook(src)  # formulas kept; we evaluate simple "=a+b" ourselves

def num(v):
    if v is None: return None
    if isinstance(v, (int, float)): return round(float(v), 2)
    s = str(v).strip()
    if s.startswith('='):
        expr = s[1:]
        if re.fullmatch(r'[\d.+\-*/() ]+', expr):
            return round(float(eval(expr)), 2)
        return None
    try: return float(s)
    except ValueError: return None

def d(v):
    return v.strftime('%Y-%m-%d') if isinstance(v, datetime.datetime) else None

ACC = {'cash': 'Cash', 'ebl': 'EBL', 'nrb': 'NRB', 'bkash': 'Bkash', 'nagad': 'Nagad', 'dbbl': 'DBBL'}
def split(tag):
    if not tag: return None, None
    a, _, dirn = str(tag).partition('_')
    return ACC.get(a.lower()), dirn.lower()

NOW = '2026-10-31T00:00:00.000Z'
n = 0
def nid(p):
    global n; n += 1; return f'seed-{p}-{n}'

ws = wb['Transection']
accounts = []
for r in range(3, 9):
    name = ws.cell(r, 7).value
    accounts.append({'id': 'acc-' + name.lower(), 'name': name, 'opening': num(ws.cell(r, 8).value) or 0, 'updatedAt': NOW})

ledger = []
for r in range(3, 126):
    date = d(ws.cell(r, 11).value) or '2026-10-01'
    acc, dirn = split(ws.cell(r, 12).value)
    amt = num(ws.cell(r, 13).value)
    purpose = ws.cell(r, 14).value
    note = ws.cell(r, 16).value or ''
    if not acc or not amt: continue
    p = str(purpose or '').strip()
    pacc, pdir = split(p)
    rec = {'id': nid('l'), 'date': date, 'account': acc, 'toAccount': '', 'amount': amt,
           'category': '', 'note': str(note), 'updatedAt': NOW}
    pl = p.lower()
    if pacc and pdir == 'in' and dirn == 'out':
        rec.update(type='transfer', toAccount=pacc)
    elif pacc and pdir == 'out' and dirn == 'in':
        rec.update(type='transfer', account=pacc, toAccount=acc)
    elif pl == 'expense':
        rec.update(type='expense', category='General')
    elif pl == 'service charge':
        rec.update(type='expense', category='Service Charge')
    elif pl == 'receivable_out':
        rec.update(type='lend')
    elif pl == 'receivable_in':
        rec.update(type='collect')
    elif pl == 'payable_in':
        rec.update(type='borrow')
    elif pl == 'payable_out':
        rec.update(type='repay')
    elif dirn == 'in':
        rec.update(type='income', category=p or 'Other')
    else:
        rec.update(type='expense', category=p or 'General')
    ledger.append(rec)

ws = wb['Liabilities']
dues = []
for r in range(5, 29):
    for kind, c in (('receivable', 3), ('payable', 10)):
        name, amt = ws.cell(r, c).value, num(ws.cell(r, c + 1).value)
        if not name or amt is None: continue
        dues.append({'id': nid('d'), 'kind': kind, 'name': str(name), 'amount': amt,
                     'dueDate': '', 'doneDate': d(ws.cell(r, c + 3).value) or '',
                     'note': '', 'updatedAt': NOW})

ws = wb['Prod Log']
purchases = []
for row in ws.iter_rows(min_row=2, values_only=True):
    if not row[0] or not row[1]: continue
    purchases.append({'id': nid('p'), 'date': d(row[0]) or '', 'name': str(row[1]),
                      'price': num(row[2]) or 0, 'source': str(row[3] or ''),
                      'note': str(row[4] or ''), 'updatedAt': NOW})

json.dump({'Accounts': accounts, 'Ledger': ledger, 'Dues': dues, 'Purchases': purchases},
          open(out, 'w'), ensure_ascii=False, indent=1)
print(len(accounts), len(ledger), len(dues), len(purchases))
