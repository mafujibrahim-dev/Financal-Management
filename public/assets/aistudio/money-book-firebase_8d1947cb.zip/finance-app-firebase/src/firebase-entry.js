// Firebase layer for Money Book: Auth (email/password + Google) and Firestore sync.
// Bundled into public/firebase-sync.js by `npm run build:firebase` (esbuild), so the app needs no CDN.
import { initializeApp } from 'firebase/app';
import {
  initializeAuth, indexedDBLocalPersistence, browserLocalPersistence, browserPopupRedirectResolver,
  onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail,
  GoogleAuthProvider, signInWithPopup, signOut, connectAuthEmulator,
} from 'firebase/auth';
import {
  initializeFirestore, memoryLocalCache, connectFirestoreEmulator,
  collection, doc, writeBatch, onSnapshot, query, where, serverTimestamp, Timestamp,
} from 'firebase/firestore';

let app = null, auth = null, fs = null, unsubs = [];
const clean = o => JSON.parse(JSON.stringify(o)); // Firestore rejects undefined values

function stop() { unsubs.forEach(u => { try { u(); } catch { /* ignore */ } }); unsubs = []; }

window.MoneyFB = {
  /** config: the web-app config object from Firebase console (+ optional `emulator: "127.0.0.1"` for local testing). */
  init(config) {
    if (app) return true;
    const { emulator, ...cfg } = config;
    app = initializeApp(cfg);
    auth = initializeAuth(app, { persistence: [indexedDBLocalPersistence, browserLocalPersistence], popupRedirectResolver: browserPopupRedirectResolver });
    // The app keeps its own offline copy in localStorage, so Firestore only needs a memory cache.
    fs = initializeFirestore(app, { localCache: memoryLocalCache() });
    if (emulator) {
      connectAuthEmulator(auth, `http://${emulator}:9099`, { disableWarnings: true });
      connectFirestoreEmulator(fs, emulator, 8080);
    }
    return true;
  },
  ready: () => !!app,
  projectId: () => app?.options?.projectId || '',
  user: () => auth?.currentUser || null,
  onUser: cb => onAuthStateChanged(auth, cb),
  signIn: (email, pw) => signInWithEmailAndPassword(auth, email, pw),
  signUp: (email, pw) => createUserWithEmailAndPassword(auth, email, pw),
  resetPassword: email => sendPasswordResetEmail(auth, email),
  google: () => signInWithPopup(auth, new GoogleAuthProvider()),
  signOut: () => { stop(); return signOut(auth); },

  /** Upload records: { Ledger: [rec, …], … } → users/{uid}/{table}/{id}. Resolves when the server confirms. */
  async push(changes) {
    const uid = auth.currentUser.uid, all = [];
    Object.entries(changes).forEach(([t, list]) => list.forEach(r => all.push([t, r])));
    for (let i = 0; i < all.length; i += 400) {
      const batch = writeBatch(fs);
      all.slice(i, i + 400).forEach(([t, r]) => batch.set(doc(fs, 'users', uid, t, String(r.id)), { ...clean(r), syncedAt: serverTimestamp() }));
      await batch.commit();
    }
    return all.length;
  },

  /** Live listener per table for records changed after `sinceMs`. onRows(table, rows, maxSyncedMs).
   *  Returns a promise that resolves once every table has delivered its first snapshot. */
  listen(tables, sinceMs, onRows, onError) {
    stop();
    const uid = auth.currentUser.uid;
    let pending = tables.length, done;
    const ready = new Promise(res => { done = res; });
    tables.forEach(t => {
      let first = true;
      const q = query(collection(fs, 'users', uid, t), where('syncedAt', '>', Timestamp.fromMillis(sinceMs || 0)));
      unsubs.push(onSnapshot(q, snap => {
        const rows = []; let max = 0;
        snap.docChanges().forEach(ch => {
          if (ch.type === 'removed' || ch.doc.metadata.hasPendingWrites) return;
          const d = ch.doc.data(), ms = d.syncedAt?.toMillis?.() || 0;
          if (ms > max) max = ms;
          delete d.syncedAt;
          rows.push(d);
        });
        if (rows.length) onRows(t, rows, max);
        if (first) { first = false; if (--pending === 0) done(); }
      }, err => { if (first) { first = false; if (--pending === 0) done(); } onError(err); }));
    });
    return ready;
  },
  stop,
};
